zip wanalyze.zip -r LICENSE README.MD *.sh design_notes src *.sh test_cases/*/*.wasm test_cases/*/*.c test_cases/*.sh \
    test_cases/dhry/src test_cases/ebpf/src test_cases/musl
cp wanalyze.zip /users/johnshortt/"VirtualBox Shared"
