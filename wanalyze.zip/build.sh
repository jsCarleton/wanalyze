eval $(opam env)
corebuild -I src -pkgs core_unix wanalyze.native
